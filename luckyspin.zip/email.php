<?php
// Youtube : RazorID YT
$razoridyt = 'saputraandi17838@gmail.com'; // GANTI EMAIL KAMU DISINI
?>
